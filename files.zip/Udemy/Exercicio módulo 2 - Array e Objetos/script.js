array = []

function Run(){
  
    let nome = document.getElementById("nome").value;
    let sobreNome = document.getElementById("sobreNome").value;
    let peso = document.getElementById("peso").value;
    let altura = document.getElementById("altura").value;

    array.push({nome, sobreNome, peso, altura})

    console.log(array);

    document.write + nome, sobreNome, peso, altura;

    document.documentElement.innerHTML += nome += "\n";
    document.documentElement.innerHTML += sobreNome += "\n";
    document.documentElement.innerHTML += peso += "\n";
    document.documentElement.innerHTML += altura += "\n";

    document.documentElement.innerHTML += "<br/>";
    document.documentElement.innerHTML += "<br/>";

}